tinyMCE.addI18n('it.youtube',{
	desc : 'Insert youtube video'
});
