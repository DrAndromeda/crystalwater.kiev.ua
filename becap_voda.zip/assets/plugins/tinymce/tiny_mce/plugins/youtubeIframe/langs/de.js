tinyMCE.addI18n('de.youtube',{
	desc : 'Insert youtube video'
});
