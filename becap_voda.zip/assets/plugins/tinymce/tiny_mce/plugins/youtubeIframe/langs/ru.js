tinyMCE.addI18n('ru.youtube',{
	desc : 'Добавить Youtube видео'
});
