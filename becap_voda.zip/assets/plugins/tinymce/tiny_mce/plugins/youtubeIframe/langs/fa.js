tinyMCE.addI18n('fa.youtube',{
	desc : 'Insert youtube video'
});
