tinyMCE.addI18n('nn.youtube',{
	desc : 'Insert youtube video'
});
