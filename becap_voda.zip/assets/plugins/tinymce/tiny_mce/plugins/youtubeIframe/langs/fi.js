tinyMCE.addI18n('fi.youtube',{
	desc : 'Insert youtube video'
});
