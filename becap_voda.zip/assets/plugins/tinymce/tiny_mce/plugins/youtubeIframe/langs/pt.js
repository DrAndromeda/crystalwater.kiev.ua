tinyMCE.addI18n('pt.youtube',{
	desc : 'Insert youtube video'
});
