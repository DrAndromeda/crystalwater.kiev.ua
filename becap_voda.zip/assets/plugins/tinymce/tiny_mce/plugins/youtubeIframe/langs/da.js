tinyMCE.addI18n('da.youtube',{
	desc : 'Insert youtube video'
});
