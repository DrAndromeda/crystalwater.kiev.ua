tinyMCE.addI18n('bg.youtube',{
	desc : 'Insert youtube video'
});
