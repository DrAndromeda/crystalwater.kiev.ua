tinyMCE.addI18n('cs.youtube',{
	desc : 'Insert youtube video'
});
