tinyMCE.addI18n('sv.youtube',{
	desc : 'Insert youtube video'
});
