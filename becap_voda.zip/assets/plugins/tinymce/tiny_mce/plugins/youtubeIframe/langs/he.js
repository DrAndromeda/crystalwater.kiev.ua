tinyMCE.addI18n('he.youtube',{
	desc : 'Insert youtube video'
});
