tinyMCE.addI18n('ja.youtube',{
	desc : 'Insert youtube video'
});
