tinyMCE.addI18n('pl.youtube',{
	desc : 'Insert youtube video'
});
