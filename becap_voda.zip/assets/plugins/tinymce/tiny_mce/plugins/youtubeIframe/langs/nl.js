tinyMCE.addI18n('nl.youtube',{
	desc : 'Insert youtube video'
});
