tinyMCE.addI18n('es.youtube',{
	desc : 'Insert youtube video'
});
