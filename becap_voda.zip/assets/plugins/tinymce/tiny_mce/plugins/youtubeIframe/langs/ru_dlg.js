tinyMCE.addI18n('ru.youtube_dlg',{
    title: 'Вставить/редактировать youtube видео',
    url_field: 'YouTube ссылка или код:',
    url_example1: 'пример URL',
    url_example2: 'пример Code',
    choose_size: 'выберите размер',
    custom: 'Задать размер',
    Width: 'Ширина',
    Height: 'Высота',
    iframe: 'iFrame - новый',
    embed: 'Embeded - старый'
});
