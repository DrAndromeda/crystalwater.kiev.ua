tinyMCE.addI18n('pt.youtube_dlg',{
    title: 'Insert/edit youtube videos',
    url_field: 'YouTube video url or code:',
    url_example1: 'URL Example',
    url_example2: 'Code Example',
    choose_size: 'Choose size',
    custom: 'Custom',
    Width: 'Width',
    Height: 'Height',
    iframe: 'New iFrame style',
    embed: 'Old Embeded Style'
});
