tinyMCE.addI18n('fr.youtube',{
	desc : 'Insert youtube video'
});
