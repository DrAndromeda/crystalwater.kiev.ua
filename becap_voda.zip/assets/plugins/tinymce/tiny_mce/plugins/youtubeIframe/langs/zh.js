tinyMCE.addI18n('zh.youtube',{
	desc : 'Insert youtube video'
});
